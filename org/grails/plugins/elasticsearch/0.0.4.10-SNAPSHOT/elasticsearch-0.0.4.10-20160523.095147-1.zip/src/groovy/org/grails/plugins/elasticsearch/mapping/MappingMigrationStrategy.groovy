package org.grails.plugins.elasticsearch.mapping

/**
 * Created by @marcos-carceles on 22/12/14.
 */
enum MappingMigrationStrategy {
    none, delete, alias
}